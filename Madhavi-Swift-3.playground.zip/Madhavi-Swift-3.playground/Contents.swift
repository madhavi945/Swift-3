import UIKit
class Computer {       //Base class to represent a general computer
    private var brands: [String] = [] //Stores the brand names of computers
    private var processors: [String] = [] //Stores processors
    private var rams: [Int] = []  //Stores the ram size of computers in GB
    private var details: [String:Any] = [:] //Dictionary to store additional details of each computer
    
    init(){
        // Do nothing
    }
    //Method to add a new computer to the collection
    func addComputer(brand: String, processor: String, ram: Int, additionalDetails: [String:Any]) {
        self.brands.append(brand) //add the brands to the collection
        self.processors.append(processor)//add the processor to the processors aray
        self.rams.append(ram) //add the RAM size to the rqms array
        self.details["\(brand)_\(processor)"] = additionalDetails
    }//Add additional details to dictionary
    //Method to update computers properties
    func updateComputer(brand: String, newProcessor: String,newRam: Int, newDetails: [String:Any]) {
        var idx = 0 //loop to find matching computer
        while idx < brands.count {
            if brands[idx] == brand {
                processors[idx] = newProcessor
                rams[idx] = newRam
                details["\(brand)_\(newProcessor)"] = newDetails
            }
            idx += 1
        }
    }
    //Method to list all computers in the collection
    func listComputers() {
        var idx = 0
        print()
        while idx < brands.count {
            print("Brand:\(brands[idx]), Processor:\(processors[idx]), RAM:\(rams[idx])GB")
            if let additionalDetails = details["\(brands[idx])_\(processors[idx])"] {
                print("Details: \(additionalDetails)")
                
            }
            idx += 1
        }
    }
}
    //creating a subclass to represent a laptop
    class Laptop: Computer {
        //Method to add a laptop with touchscreen details
        func addLaptop(brand: String, processor: String, ram: Int, isTouchscreen: Bool) {
            addComputer(
                brand: brand,
                processor: processor,
                ram: ram,
                additionalDetails: ["Touchscreen": isTouchscreen]
            )
        }
    }
        //subclass to represent a desktop
    class Desktop: Computer {
        //method to add a desktop with GPU details
        func addDesktop(brand: String, processor: String, ram: Int, hasDedicatedGPU:Bool) {
            addComputer(
                brand: brand,
                processor: processor,
                ram: ram,
                additionalDetails: ["Dedicated GPU": hasDedicatedGPU]
            )
        }
    }
            //subclss to represent server
            class Server: Computer {
                //method to add a server with rack units
                func addServer(brand: String, processor: String, ram: Int, rackUnits: Int) {
                    addComputer(
                        brand: brand,
                        processor: processor,
                        ram: ram,
                        additionalDetails: ["Rack units":rackUnits]
                    )
                }
            }
                //Testing with classes
                var laptopCollection: Laptop = Laptop()
                var desktopCollection: Desktop = Desktop()
                var serverCollection: Server = Server()
                //Adding laptops to the collection
                laptopCollection.addLaptop(brand: "Apple", processor: "M1", ram: 16, isTouchscreen: true)
                desktopCollection.addDesktop(brand: "Dell", processor: "Intel i7", ram: 32, hasDedicatedGPU: true)
                serverCollection.addServer(brand: "HP", processor: "Xeon", ram: 64, rackUnits: 4)
                print("Laptop Collection:") //listing laptops
                laptopCollection.listComputers()
                print("\nDesktop Collection:") //listing desktops
                desktopCollection.listComputers()
                print("\nServer Collection:")//listing servers
                serverCollection.listComputers()
                
                
                
                
                
